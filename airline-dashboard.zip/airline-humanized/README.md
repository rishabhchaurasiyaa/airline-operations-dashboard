# Airline Operations Dashboard — JavaScript Edition

## Run locally
1. Extract this folder.
2. Open `index.html` in Chrome, or use VS Code Live Server.
3. Add records from the sidebar modules.

## Technology
- HTML5
- CSS3 (adapted from the supplied project stylesheet)
- Vanilla JavaScript
- Browser localStorage

## Important storage limitation
Records are saved only in the browser profile/device where they were entered. They are not synchronized between users or devices. Export Backup / Import Backup lets you move data manually as a JSON file.

## GitHub Pages
Upload the contents of this folder to a GitHub repository, with `index.html` at the repository root, then enable GitHub Pages from Settings → Pages → Deploy from a branch → `main` → `/ (root)`.

## Notes
This is a separate conversion. Your supplied PHP project remains unchanged. The original PHP files and database are not required for this static JavaScript edition.
